#!/bin/sh

echo "Start gs:"

erl -noshell -s gs start_link -sname main
